<?php

namespace App\Http\Controllers;
use App\ProductOrder;

use App\Room;
use Illuminate\Http\Request;

class ProductOrderController extends Controller
{
    function Product_Order(){
        $product_orders = ProductOrder::all();

//      $rooms = Room::orderBy("id","DESC")->paginate(5);
        return view('db.product_order')->with('product_orders',$product_orders);
    }
    function Product_Order_Form(){
        return view('form.product_order');
    }
    function Product_Order_Insert(Request $request){
        $product_order = new ProductOrder();
        $product_order->product_name = $request->product_name;
        $product_order->product_price = $request->product_price;
        $product_order->product_type = $request->product_type;
        $product_order->product_status = $request->product_status;

        if ($request->hasFile('product_img')){
            $file = $request->file('product_img')->getClientOriginalName();
            $request->file('product_img')->storeAs('public/uploads/room', $file);
            $product_order->product_img = $file;
        }
        else{
            $product_order->product_img = '';
        }

        $product_order->save();

//        session()->put('room_last_id',$product_order->id +1);

        return redirect()->route('product_orders');
    }


    function Product_Order_Delete($id){
        ProductOrder::destroy($id);
        return redirect()->route('product_orders');
    }
}
