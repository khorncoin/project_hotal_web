<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ProductOrder extends Model
{
    protected $table = 'product_order';
    protected $fillable = ['product_name','product_price','product_type','product_img','product_status'];
}
